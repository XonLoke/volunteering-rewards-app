
  # Admin Web Portal Setup (Copy)

  This is a code bundle for Admin Web Portal Setup (Copy). The original project is available at https://www.figma.com/design/pdC25mRJs51i719YN0ukpX/Admin-Web-Portal-Setup--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  