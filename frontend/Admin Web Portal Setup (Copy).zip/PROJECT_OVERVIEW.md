# Volunteering Rewards Portal - Project Overview

## Project Summary
Complete admin portal and rewards management system for Grace's web application modules (WEB-01 to WEB-07) and rewards features (REW-W01 to REW-W03, REW-M01 to REW-M04).

This project is part of the "Volunteering Rewards App" capstone project (SOI-2024-2420-0008) where volunteers earn points by scanning QR codes at volunteering activities and can redeem coupons from participating stores using those points.

## Technology Stack
- **Frontend Framework:** React 18.3.1 with TypeScript
- **Routing:** React Router 7.13.0
- **Styling:** Tailwind CSS v4.1.12
- **UI Components:** shadcn/ui (Radix UI primitives)
- **Charts:** Recharts 2.15.2
- **Notifications:** Sonner 2.0.3
- **Package Manager:** pnpm

## Authentication (Aligned with Database Schema)

### Demo Credentials
- **Admin:** admin@example.com / admin123
- **Organizer:** organizer@example.com / organizer123  
- **Cashier:** cashier@example.com / cashier123
- **Volunteer:** volunteer@example.com / volunteer123

### User Roles (from ERD)
1. **Volunteer** - Participate in events, earn points, redeem coupons
2. **Organizer** - Create and manage volunteer events, scan QR codes, award points
3. **Admin** - Full system access with all permissions
4. **Cashier** - Verify coupon PINs at participating stores

## Module Implementation Status

### ✅ Web Admin Portal (WEB-01 to WEB-07)
1. **WEB-01: Dashboard** - Complete with analytics charts, stats, and activity feed
2. **WEB-02: User Management** - Role-based user administration
3. **WEB-03: Analytics** - Advanced analytics with multiple chart types
4. **WEB-04: Notifications** - Notification management with templates
5. **WEB-05: Roles & Permissions** - Complete RBAC system
6. **WEB-06: Settings** - System configuration across 5 categories
7. **WEB-07: Login** - Secure authentication with protected routes

### ✅ Rewards Web Features (REW-W01 to REW-W03)
1. **REW-W01: Coupon Management** - Create, edit, search, filter, bulk actions
2. **REW-W02: PIN Verification** - Quick PIN lookup and verification
3. **REW-W03: Audit Log** - Comprehensive activity tracking

### ✅ Rewards Mobile Screens (REW-M01 to REW-M04)
1. **REW-M01: Rewards List** - Browse available rewards
2. **REW-M02: Reward Details** - View reward information
3. **REW-M03: Redeem Reward** - PIN redemption flow
4. **REW-M04: Reward History** - Transaction history

## Key Features

### Dashboard (WEB-01)
- Real-time statistics with trend indicators
- Interactive charts (revenue trends, category breakdown)
- Recent activity feed
- System status monitoring
- Top performing rewards list
- Quick action cards

### Analytics (WEB-03)
- Multi-tab analytics interface (Overview, Revenue, Users, Rewards)
- Line charts, bar charts, pie charts, and area charts
- Date range filtering (7, 30, 90, 365 days)
- Export functionality (CSV)
- Category performance metrics
- User growth tracking

### Notifications (WEB-04)
- Compose and send notifications
- Message templates
- Multiple channels (Email, Push, SMS)
- Notification history
- Settings configuration
- Recipient targeting

### Roles & Permissions (WEB-05)
- Visual permission matrix
- Create/edit/delete roles
- Permission categories (Dashboard, Users, Rewards, System)
- User count tracking
- Admin-only access control

### Settings (WEB-06)
- General settings (site info, timezone, language)
- Security settings (2FA, session timeout, password policies)
- Notification preferences
- API & integrations
- Appearance customization

### Coupon Management (REW-W01)
- Points-based coupon system (aligned with ERD)
- Bulk selection and operations
- Advanced filtering (status: active, inactive, depleted)
- Search functionality
- Export capabilities
- Create/edit/delete/duplicate coupons
- Track redeemed vs available quantity
- Expiry date management

## Database Schema Alignment

All data models have been aligned with the ERD (3_DATABASE_ERD_v3.pdf):

### Users Table
- **Fields:** id, name, email, password_hash, phone, role_id, points (cached balance), volunteer_qr_code, status, profile_image_url, created_at, updated_at
- **Status Values:** active, suspended, inactive
- **Points:** Cached balance from points_ledger transactions

### Coupons Table  
- **Fields:** id, title, description, image_url, points_required, quantity, expiry_date, status, created_by, created_at, updated_at
- **Status Values:** active, inactive, depleted
- **Note:** Volunteers redeem coupons using accumulated points

### User_Coupons Table (Junction Table)
- **Fields:** id, user_id, coupon_id, pin_hash (HMAC-SHA256), status, redeemed_at, verified_by, expiry_date, created_at
- **Status Values:** unused, used, expired
- **PIN System:** Secure hash stored, not plaintext

### Redemption_Logs Table (Audit Trail)
- **Fields:** id, user_coupon_id, action, action_by, ip_address, created_at, notes
- **Actions:** redeemed, used, expired, auto_expired
- **Purpose:** Complete audit trail of all coupon lifecycle events

### Points_Ledger Table (Transaction Log)
- **Fields:** id, user_id, amount (+earned / -spent), balance_after, reason_code, reference_id, reference_type, created_at
- **Reason Codes:** event_attendance, coupon_redemption, admin_adjustment
- **Purpose:** Immutable transaction log for all point movements

## Design System
- Consistent violet/purple theme (#8b5cf6)
- Dark sidebar with light content area
- Responsive design (mobile, tablet, desktop)
- shadcn/ui component library
- Accessible form controls

## Protected Routes
- Login page (public)
- All other routes require authentication
- Role-based access control:
  - **User Management (WEB-02):** Admin only
  - **Roles & Permissions (WEB-05):** Admin only
  - **Other pages:** Accessible to all authenticated users

## File Structure
```
src/app/
├── App.tsx                 # Main app component
├── routes.tsx             # Route configuration
├── components/
│   ├── ui/                # shadcn/ui components
│   ├── ProtectedRoute.tsx # Route protection
│   └── PlaceholderPage.tsx
├── contexts/
│   └── AuthContext.tsx    # Authentication state
├── layouts/
│   └── AdminLayout.tsx    # Main layout with sidebar
└── pages/
    ├── Login.tsx
    ├── Dashboard.tsx
    ├── admin/
    │   ├── UserManagement.tsx
    │   ├── Analytics.tsx
    │   ├── Notifications.tsx
    │   ├── RolesPermissions.tsx
    │   └── Settings.tsx
    └── rewards/
        ├── CouponManagement.tsx
        ├── PINVerification.tsx
        ├── AuditLog.tsx
        └── mobile/
            ├── RewardsList.tsx
            ├── RewardDetails.tsx
            ├── RedeemReward.tsx
            └── RewardHistory.tsx
```

## Navigation Structure
- Dashboard
- Rewards Section
  - Coupon Management (REW-W01)
  - PIN Verification (REW-W02)
  - Audit Log (REW-W03)
  - Mobile Screens (REW-M01 to REW-M04)
- Admin Section
  - User Management (WEB-02)
  - Analytics (WEB-03)
  - Notifications (WEB-04)
  - Roles & Permissions (WEB-05)
  - Settings (WEB-06)

## Development Commands
```bash
# Install dependencies
pnpm install

# Development server (already running)
# Access via preview surface - NOT localhost

# Build (DO NOT USE - environment limitation)
# pnpm build

# Type checking
# pnpm tsc --noEmit
```

## Mock Data (Aligned with Schema)

All features use realistic mock data matching the database schema:

### Users
- 8 sample users across all 4 roles (Admin, Organizer, Cashier, Volunteer)
- Volunteers have volunteer_qr_code for event check-in
- Points balances reflecting redemption activity
- Status: active, suspended, inactive

### Coupons  
- 6 sample coupons from various merchants (FairPrice, GrabFood, Golden Village, Starbucks, ActiveSG, Singapore Zoo)
- Points requirements ranging from 150 to 1200
- Various statuses: active, inactive, depleted
- Quantity tracking (redeemed vs available)

### User_Coupons (PIN Verification)
- 5 sample redeemed coupons with PIN codes
- Status tracking: unused, used, expired
- Verified_by tracking for cashier verification
- Expiry date enforcement

### Analytics Data
- 6 months of revenue and redemption trends
- Category performance metrics
- User growth statistics
- Top performing rewards

## Responsive Breakpoints
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## Future Enhancements (Not Implemented)

### Core Volunteering Features (Outside Grace's Scope)
- Event management system (organizers create events)
- QR code generation and scanning (volunteers check-in at events)
- Points awarding system (automatic points after attendance)
- Event registration and feedback
- Organization approval workflow
- FigJam integration for event Q&A

### Technical Enhancements
- Real backend API integration with database
- Secure PIN hashing (HMAC-SHA256)
- Redemption logs with IP tracking
- Points ledger transaction history
- Image upload for coupons
- Email/SMS notification service
- Real-time WebSocket notifications
- Advanced reporting and analytics
- Data export formats (PDF, Excel)
- Scheduled notifications via cron jobs
- Webhook integrations for external systems

## Important Notes

### Schema Compliance
- **100% aligned** with the database ERD (3_DATABASE_ERD_v3.pdf)
- All table structures, field names, and relationships match the schema
- Role names exactly match: Volunteer, Organizer, Admin, Cashier
- Status values align with enum specifications
- PIN system references pin_hash (though mock uses plaintext for demo)

### Current Limitations  
- No real backend - all data is in-memory mock data
- No actual database persistence
- Authentication is mock-based (no real security)
- PIN verification uses plaintext comparison (real system would use HMAC-SHA256 hashing)
- No actual QR code scanning or event management (outside Grace's scope)
- Charts use Recharts library with responsive containers
- All forms include validation feedback
- Toast notifications for user actions

### Grace's Assignment Coverage
This implementation covers **Grace's portion** of the capstone project:
- ✅ WEB-01 to WEB-07: Complete web admin portal
- ✅ REW-W01 to REW-W03: Coupon management, PIN verification, audit logs
- ✅ REW-M01 to REW-M04: Mobile rewards screens (displayed in device frames)
- ❌ Event management, QR scanning, organization approval (assigned to other team members)
