import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Construction } from 'lucide-react';
import { Link } from 'react-router';

interface PlaceholderPageProps {
  title: string;
  badge: string;
  description: string;
}

export default function PlaceholderPage({ title, badge, description }: PlaceholderPageProps) {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-slate-900">{title}</h1>
          <Badge>{badge}</Badge>
        </div>
        <p className="text-slate-500 mt-1">{description}</p>
      </div>

      {/* Coming Soon Card */}
      <Card>
        <CardHeader>
          <CardTitle>Coming Soon</CardTitle>
          <CardDescription>This feature is under development</CardDescription>
        </CardHeader>
        <CardContent className="h-96 flex items-center justify-center bg-slate-50 rounded-lg">
          <div className="text-center">
            <Construction className="h-16 w-16 text-slate-300 mx-auto mb-4" />
            <p className="text-lg font-medium text-slate-700 mb-2">{title}</p>
            <p className="text-slate-500 mb-6">
              This page is part of the {badge} module
            </p>
            <Link to="/">
              <Button>Back to Dashboard</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
