import { createBrowserRouter, Navigate } from 'react-router';
import { useAuth } from './contexts/AuthContext';
import AdminLayout from './layouts/AdminLayout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import CouponManagement from './pages/rewards/CouponManagement';
import PINVerification from './pages/rewards/PINVerification';
import AuditLog from './pages/rewards/AuditLog';
import RewardsList from './pages/rewards/mobile/RewardsList';
import RewardDetails from './pages/rewards/mobile/RewardDetails';
import RedeemReward from './pages/rewards/mobile/RedeemReward';
import RewardHistory from './pages/rewards/mobile/RewardHistory';
import UserManagement from './pages/admin/UserManagement';
import Analytics from './pages/admin/Analytics';
import Notifications from './pages/admin/Notifications';
import RolesPermissions from './pages/admin/RolesPermissions';
import Settings from './pages/admin/Settings';
import ProtectedRoute from './components/ProtectedRoute';

// Helper component to redirect if authenticated
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <Navigate to="/" replace /> : <>{children}</>;
}

export const router = createBrowserRouter([
  {
    path: '/login',
    element: (
      <PublicRoute>
        <Login />
      </PublicRoute>
    ),
  },
  {
    path: '/',
    element: (
      <ProtectedRoute>
        <AdminLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <Dashboard />,
      },
      // Rewards Web Pages (REW-W01 to REW-W03)
      {
        path: 'rewards/coupons',
        element: <CouponManagement />,
      },
      {
        path: 'rewards/pin-verify',
        element: <PINVerification />,
      },
      {
        path: 'rewards/audit',
        element: <AuditLog />,
      },
      // Rewards Mobile Screens (REW-M01 to REW-M04)
      {
        path: 'rewards/mobile/list',
        element: <RewardsList />,
      },
      {
        path: 'rewards/mobile/details',
        element: <RewardDetails />,
      },
      {
        path: 'rewards/mobile/redeem',
        element: <RedeemReward />,
      },
      {
        path: 'rewards/mobile/history',
        element: <RewardHistory />,
      },
      // Admin Pages (WEB-02 to WEB-07)
      {
        path: 'admin/users',
        element: (
          <ProtectedRoute allowedRoles={['Admin']}>
            <UserManagement />
          </ProtectedRoute>
        ),
      },
      {
        path: 'admin/analytics',
        element: <Analytics />,
      },
      {
        path: 'admin/notifications',
        element: <Notifications />,
      },
      {
        path: 'admin/roles',
        element: (
          <ProtectedRoute allowedRoles={['Admin']}>
            <RolesPermissions />
          </ProtectedRoute>
        ),
      },
      {
        path: 'admin/settings',
        element: <Settings />,
      },
    ],
  },
  {
    path: '*',
    element: <Navigate to="/" replace />,
  },
]);
