import React, { createContext, useContext, useState, ReactNode } from 'react';

// Roles match the database schema from ERD
export type UserRole = 'Volunteer' | 'Organizer' | 'Admin' | 'Cashier';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  points: number; // Cached balance from points_ledger
  volunteer_qr_code?: string; // For volunteer role
  status: 'active' | 'suspended' | 'inactive';
  profile_image_url?: string;
  created_at: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demo purposes - aligned with database schema
const MOCK_USERS: Record<string, { password: string; user: User }> = {
  'admin@example.com': {
    password: 'admin123',
    user: {
      id: '1',
      name: 'Grace Admin',
      email: 'admin@example.com',
      role: 'Admin',
      phone: '+65 9123 4567',
      points: 0,
      status: 'active',
      created_at: '2024-01-15T08:00:00Z',
    },
  },
  'organizer@example.com': {
    password: 'organizer123',
    user: {
      id: '2',
      name: 'Grace Organizer',
      email: 'organizer@example.com',
      role: 'Organizer',
      phone: '+65 9234 5678',
      points: 0,
      status: 'active',
      created_at: '2024-02-10T09:30:00Z',
    },
  },
  'cashier@example.com': {
    password: 'cashier123',
    user: {
      id: '3',
      name: 'Grace Cashier',
      email: 'cashier@example.com',
      role: 'Cashier',
      phone: '+65 9345 6789',
      points: 0,
      status: 'active',
      created_at: '2024-03-05T10:15:00Z',
    },
  },
  'volunteer@example.com': {
    password: 'volunteer123',
    user: {
      id: '4',
      name: 'Grace Volunteer',
      email: 'volunteer@example.com',
      role: 'Volunteer',
      phone: '+65 9456 7890',
      points: 1250,
      volunteer_qr_code: 'VOL-2024-001234',
      status: 'active',
      created_at: '2024-01-20T14:00:00Z',
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string) => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const mockUser = MOCK_USERS[email];
    if (mockUser && mockUser.password === password) {
      setUser(mockUser.user);
    } else {
      throw new Error('Invalid credentials');
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
