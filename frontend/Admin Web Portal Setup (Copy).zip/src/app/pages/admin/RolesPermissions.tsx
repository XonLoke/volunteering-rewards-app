import { useState } from 'react';
import { Shield, Users, Key, Plus, Edit, Trash2, Save, X } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Badge } from '../../components/ui/badge';
import { Checkbox } from '../../components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../../components/ui/dialog';
import { toast } from 'sonner';

type Permission = {
  id: string;
  name: string;
  description: string;
  category: string;
};

type Role = {
  id: string;
  name: string;
  description: string;
  userCount: number;
  permissions: string[];
  color: string;
};

// Permissions aligned with Volunteering Rewards App functionality
const PERMISSIONS: Permission[] = [
  { id: 'view_dashboard', name: 'View Dashboard', description: 'Access to main dashboard', category: 'Dashboard' },
  { id: 'view_analytics', name: 'View Analytics', description: 'View analytics and reports', category: 'Dashboard' },

  { id: 'manage_users', name: 'Manage Users', description: 'Create, edit, delete users', category: 'Users' },
  { id: 'view_users', name: 'View Users', description: 'View user list and details', category: 'Users' },
  { id: 'manage_roles', name: 'Manage Roles', description: 'Create and edit roles', category: 'Users' },
  { id: 'approve_organizations', name: 'Approve Organizations', description: 'Approve organization registrations', category: 'Users' },

  { id: 'manage_events', name: 'Manage Events', description: 'Create and manage volunteer events', category: 'Events' },
  { id: 'view_events', name: 'View Events', description: 'View event listings', category: 'Events' },
  { id: 'scan_attendance', name: 'Scan Attendance', description: 'Scan QR codes for attendance', category: 'Events' },
  { id: 'award_points', name: 'Award Points', description: 'Award points to volunteers', category: 'Events' },

  { id: 'manage_coupons', name: 'Manage Coupons', description: 'Create, edit coupons', category: 'Rewards' },
  { id: 'redeem_coupons', name: 'Redeem Coupons', description: 'Redeem coupons for points', category: 'Rewards' },
  { id: 'verify_pins', name: 'Verify PINs', description: 'Verify coupon PINs', category: 'Rewards' },
  { id: 'view_audit', name: 'View Audit Logs', description: 'Access audit trail', category: 'Rewards' },

  { id: 'send_notifications', name: 'Send Notifications', description: 'Send system notifications', category: 'System' },
  { id: 'manage_settings', name: 'Manage Settings', description: 'Configure system settings', category: 'System' },
];

export default function RolesPermissions() {
  const [roles, setRoles] = useState<Role[]>([
    {
      id: '1',
      name: 'Admin',
      description: 'Full system access with all permissions',
      userCount: 1,
      permissions: PERMISSIONS.map((p) => p.id),
      color: 'bg-red-500',
    },
    {
      id: '2',
      name: 'Organizer',
      description: 'Create and manage volunteer events, scan QR codes, award points',
      userCount: 2,
      permissions: [
        'view_dashboard',
        'view_analytics',
        'view_users',
        'manage_events',
        'view_events',
        'scan_attendance',
        'award_points',
        'view_audit',
      ],
      color: 'bg-blue-500',
    },
    {
      id: '3',
      name: 'Cashier',
      description: 'Verify coupon PINs at participating stores',
      userCount: 2,
      permissions: ['view_dashboard', 'verify_pins', 'view_audit'],
      color: 'bg-purple-500',
    },
    {
      id: '4',
      name: 'Volunteer',
      description: 'Participate in events, earn points, redeem coupons',
      userCount: 3,
      permissions: ['view_events', 'redeem_coupons'],
      color: 'bg-green-500',
    },
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    permissions: [] as string[],
  });

  const handleCreateRole = () => {
    setEditingRole(null);
    setFormData({ name: '', description: '', permissions: [] });
    setIsDialogOpen(true);
  };

  const handleEditRole = (role: Role) => {
    setEditingRole(role);
    setFormData({
      name: role.name,
      description: role.description,
      permissions: role.permissions,
    });
    setIsDialogOpen(true);
  };

  const handleSaveRole = () => {
    if (!formData.name || !formData.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingRole) {
      setRoles(
        roles.map((role) =>
          role.id === editingRole.id
            ? { ...role, name: formData.name, description: formData.description, permissions: formData.permissions }
            : role
        )
      );
      toast.success('Role updated successfully');
    } else {
      const newRole: Role = {
        id: Date.now().toString(),
        name: formData.name,
        description: formData.description,
        userCount: 0,
        permissions: formData.permissions,
        color: 'bg-purple-500',
      };
      setRoles([...roles, newRole]);
      toast.success('Role created successfully');
    }

    setIsDialogOpen(false);
  };

  const handleDeleteRole = (roleId: string) => {
    const role = roles.find((r) => r.id === roleId);
    if (role && role.userCount > 0) {
      toast.error(`Cannot delete role with ${role.userCount} assigned users`);
      return;
    }
    setRoles(roles.filter((r) => r.id !== roleId));
    toast.success('Role deleted successfully');
  };

  const togglePermission = (permissionId: string) => {
    setFormData({
      ...formData,
      permissions: formData.permissions.includes(permissionId)
        ? formData.permissions.filter((p) => p !== permissionId)
        : [...formData.permissions, permissionId],
    });
  };

  const groupedPermissions = PERMISSIONS.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {} as Record<string, Permission[]>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold">Roles & Permissions</h1>
          <p className="text-[--color-text-secondary] mt-1">
            Manage user roles and access control
          </p>
        </div>
        <Badge variant="outline">WEB-05</Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Roles</CardTitle>
            <Shield className="h-4 w-4 text-[--color-text-secondary]" />
          </CardHeader>
          <CardContent>
            <div className="font-bold">{roles.length}</div>
            <p className="text-xs text-[--color-text-secondary]">
              Active role configurations
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assigned Users</CardTitle>
            <Users className="h-4 w-4 text-[--color-text-secondary]" />
          </CardHeader>
          <CardContent>
            <div className="font-bold">{roles.reduce((sum, role) => sum + role.userCount, 0)}</div>
            <p className="text-xs text-[--color-text-secondary]">
              Users with role assignments
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Permissions</CardTitle>
            <Key className="h-4 w-4 text-[--color-text-secondary]" />
          </CardHeader>
          <CardContent>
            <div className="font-bold">{PERMISSIONS.length}</div>
            <p className="text-xs text-[--color-text-secondary]">
              Available permissions
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="roles" className="space-y-4">
        <TabsList>
          <TabsTrigger value="roles">Roles</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="roles" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Role Management</CardTitle>
                  <CardDescription>Create and manage user roles</CardDescription>
                </div>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={handleCreateRole}>
                      <Plus className="mr-2 h-4 w-4" />
                      Create Role
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingRole ? 'Edit Role' : 'Create New Role'}</DialogTitle>
                      <DialogDescription>
                        Configure role details and assign permissions
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="role-name">Role Name</Label>
                        <Input
                          id="role-name"
                          placeholder="Enter role name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="role-description">Description</Label>
                        <Input
                          id="role-description"
                          placeholder="Enter role description"
                          value={formData.description}
                          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        />
                      </div>
                      <div className="space-y-4">
                        <Label>Permissions</Label>
                        {Object.entries(groupedPermissions).map(([category, permissions]) => (
                          <div key={category} className="space-y-2">
                            <h4 className="text-sm font-medium">{category}</h4>
                            <div className="space-y-2 ml-4">
                              {permissions.map((permission) => (
                                <div key={permission.id} className="flex items-center space-x-2">
                                  <Checkbox
                                    id={permission.id}
                                    checked={formData.permissions.includes(permission.id)}
                                    onCheckedChange={() => togglePermission(permission.id)}
                                  />
                                  <label
                                    htmlFor={permission.id}
                                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                                  >
                                    <div>{permission.name}</div>
                                    <div className="text-xs text-[--color-text-secondary]">
                                      {permission.description}
                                    </div>
                                  </label>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSaveRole}>
                        <Save className="mr-2 h-4 w-4" />
                        Save Role
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {roles.map((role) => (
                  <div
                    key={role.id}
                    className="border rounded-lg p-4 hover:bg-[--color-surface-hover] transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex gap-3 flex-1">
                        <div className={`w-3 h-3 rounded-full ${role.color} mt-1.5`}></div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{role.name}</h4>
                            <Badge variant="secondary" className="text-xs">
                              {role.userCount} users
                            </Badge>
                          </div>
                          <p className="text-sm text-[--color-text-secondary] mt-1">
                            {role.description}
                          </p>
                          <div className="flex flex-wrap gap-1 mt-3">
                            {role.permissions.map((permId) => {
                              const perm = PERMISSIONS.find((p) => p.id === permId);
                              return perm ? (
                                <Badge key={permId} variant="outline" className="text-xs">
                                  {perm.name}
                                </Badge>
                              ) : null;
                            })}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditRole(role)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteRole(role.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Permission Matrix</CardTitle>
              <CardDescription>Overview of permissions across roles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium">Permission</th>
                      {roles.map((role) => (
                        <th key={role.id} className="text-center py-3 px-4 font-medium">
                          <div className="flex items-center justify-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${role.color}`}></div>
                            {role.name}
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(groupedPermissions).map(([category, permissions]) => (
                      <>
                        <tr key={category} className="bg-[--color-surface-hover]">
                          <td colSpan={roles.length + 1} className="py-2 px-4 text-sm font-medium">
                            {category}
                          </td>
                        </tr>
                        {permissions.map((permission) => (
                          <tr key={permission.id} className="border-b hover:bg-[--color-surface-hover]">
                            <td className="py-3 px-4">
                              <div className="font-medium text-sm">{permission.name}</div>
                              <div className="text-xs text-[--color-text-secondary]">
                                {permission.description}
                              </div>
                            </td>
                            {roles.map((role) => (
                              <td key={role.id} className="text-center py-3 px-4">
                                {role.permissions.includes(permission.id) ? (
                                  <div className="flex justify-center">
                                    <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center text-white text-xs">
                                      ✓
                                    </div>
                                  </div>
                                ) : (
                                  <div className="flex justify-center">
                                    <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 text-xs">
                                      ✕
                                    </div>
                                  </div>
                                )}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
