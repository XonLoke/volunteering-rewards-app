import { useState } from 'react';
import { Bell, Send, Users, AlertCircle, CheckCircle, Info, Plus, X } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Switch } from '../../components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { toast } from 'sonner';

type NotificationType = 'info' | 'warning' | 'success' | 'alert';

type Notification = {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  recipient: string;
  sentAt: string;
  status: 'sent' | 'scheduled' | 'draft';
};

type NotificationTemplate = {
  id: string;
  name: string;
  subject: string;
  body: string;
  type: NotificationType;
};

export default function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      title: 'System Maintenance',
      message: 'Scheduled maintenance on Sunday 2AM-4AM',
      type: 'warning',
      recipient: 'All Users',
      sentAt: '2026-05-15T14:30:00',
      status: 'sent',
    },
    {
      id: '2',
      title: 'New Rewards Available',
      message: 'Check out our latest rewards catalog',
      type: 'success',
      recipient: 'Active Members',
      sentAt: '2026-05-14T10:00:00',
      status: 'sent',
    },
    {
      id: '3',
      title: 'Account Security Alert',
      message: 'Please update your password',
      type: 'alert',
      recipient: 'Selected Users',
      sentAt: '2026-05-13T16:45:00',
      status: 'sent',
    },
  ]);

  const [templates] = useState<NotificationTemplate[]>([
    {
      id: '1',
      name: 'Welcome Message',
      subject: 'Welcome to our platform!',
      body: 'Thank you for joining us. Here\'s what you can do next...',
      type: 'info',
    },
    {
      id: '2',
      name: 'Reward Redemption',
      subject: 'Your reward has been redeemed',
      body: 'Congratulations! Your reward PIN: {PIN}',
      type: 'success',
    },
    {
      id: '3',
      name: 'Security Alert',
      subject: 'Security notification',
      body: 'We noticed unusual activity on your account.',
      type: 'alert',
    },
  ]);

  const [settings, setSettings] = useState({
    emailEnabled: true,
    pushEnabled: true,
    smsEnabled: false,
    autoSend: false,
  });

  const [newNotification, setNewNotification] = useState({
    title: '',
    message: '',
    type: 'info' as NotificationType,
    recipient: 'all',
  });

  const getTypeIcon = (type: NotificationType) => {
    switch (type) {
      case 'alert':
        return <AlertCircle className="h-4 w-4" />;
      case 'success':
        return <CheckCircle className="h-4 w-4" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: NotificationType) => {
    switch (type) {
      case 'alert':
        return 'destructive';
      case 'success':
        return 'default';
      case 'warning':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  const handleSendNotification = () => {
    if (!newNotification.title || !newNotification.message) {
      toast.error('Please fill in all required fields');
      return;
    }

    const notification: Notification = {
      id: Date.now().toString(),
      title: newNotification.title,
      message: newNotification.message,
      type: newNotification.type,
      recipient: newNotification.recipient === 'all' ? 'All Users' : 'Selected Users',
      sentAt: new Date().toISOString(),
      status: 'sent',
    };

    setNotifications([notification, ...notifications]);
    setNewNotification({ title: '', message: '', type: 'info', recipient: 'all' });
    toast.success('Notification sent successfully');
  };

  const handleSaveDraft = () => {
    if (!newNotification.title || !newNotification.message) {
      toast.error('Please fill in all required fields');
      return;
    }

    const notification: Notification = {
      id: Date.now().toString(),
      title: newNotification.title,
      message: newNotification.message,
      type: newNotification.type,
      recipient: newNotification.recipient === 'all' ? 'All Users' : 'Selected Users',
      sentAt: new Date().toISOString(),
      status: 'draft',
    };

    setNotifications([notification, ...notifications]);
    setNewNotification({ title: '', message: '', type: 'info', recipient: 'all' });
    toast.success('Draft saved successfully');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold">Notification Management</h1>
          <p className="text-[--color-text-secondary] mt-1">
            Send and manage system notifications
          </p>
        </div>
        <Badge variant="outline">WEB-04</Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sent</CardTitle>
            <Send className="h-4 w-4 text-[--color-text-secondary]" />
          </CardHeader>
          <CardContent>
            <div className="font-bold">1,248</div>
            <p className="text-xs text-[--color-text-secondary]">
              +12% from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Users className="h-4 w-4 text-[--color-text-secondary]" />
          </CardHeader>
          <CardContent>
            <div className="font-bold">8,924</div>
            <p className="text-xs text-[--color-text-secondary]">
              Receiving notifications
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Delivery Rate</CardTitle>
            <Bell className="h-4 w-4 text-[--color-text-secondary]" />
          </CardHeader>
          <CardContent>
            <div className="font-bold">98.5%</div>
            <p className="text-xs text-[--color-text-secondary]">
              Last 30 days average
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="compose" className="space-y-4">
        <TabsList>
          <TabsTrigger value="compose">Compose</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="compose" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>New Notification</CardTitle>
              <CardDescription>
                Create and send notifications to users
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Notification title"
                  value={newNotification.title}
                  onChange={(e) =>
                    setNewNotification({ ...newNotification, title: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Enter your notification message..."
                  rows={4}
                  value={newNotification.message}
                  onChange={(e) =>
                    setNewNotification({ ...newNotification, message: e.target.value })
                  }
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Select
                    value={newNotification.type}
                    onValueChange={(value: NotificationType) =>
                      setNewNotification({ ...newNotification, type: value })
                    }
                  >
                    <SelectTrigger id="type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="success">Success</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="alert">Alert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="recipient">Recipient</Label>
                  <Select
                    value={newNotification.recipient}
                    onValueChange={(value) =>
                      setNewNotification({ ...newNotification, recipient: value })
                    }
                  >
                    <SelectTrigger id="recipient">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="active">Active Members</SelectItem>
                      <SelectItem value="selected">Selected Users</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSendNotification} className="flex-1">
                  <Send className="mr-2 h-4 w-4" />
                  Send Now
                </Button>
                <Button onClick={handleSaveDraft} variant="outline">
                  Save Draft
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification History</CardTitle>
              <CardDescription>View all sent notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className="flex items-start justify-between border-b pb-4 last:border-0"
                  >
                    <div className="flex gap-3">
                      <div className="mt-1">{getTypeIcon(notification.type)}</div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{notification.title}</h4>
                          <Badge variant={getTypeColor(notification.type)} className="text-xs">
                            {notification.type}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {notification.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-[--color-text-secondary] mt-1">
                          {notification.message}
                        </p>
                        <div className="flex gap-4 mt-2 text-xs text-[--color-text-secondary]">
                          <span>To: {notification.recipient}</span>
                          <span>
                            {new Date(notification.sentAt).toLocaleString('en-US', {
                              dateStyle: 'medium',
                              timeStyle: 'short',
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Message Templates</CardTitle>
                  <CardDescription>Pre-configured notification templates</CardDescription>
                </div>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  New Template
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {templates.map((template) => (
                  <div
                    key={template.id}
                    className="border rounded-lg p-4 hover:bg-[--color-surface-hover] transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{template.name}</h4>
                          <Badge variant={getTypeColor(template.type)} className="text-xs">
                            {template.type}
                          </Badge>
                        </div>
                        <p className="font-medium text-sm mt-2">{template.subject}</p>
                        <p className="text-sm text-[--color-text-secondary] mt-1">
                          {template.body}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        Use Template
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure notification channels and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email">Email Notifications</Label>
                  <p className="text-sm text-[--color-text-secondary]">
                    Send notifications via email
                  </p>
                </div>
                <Switch
                  id="email"
                  checked={settings.emailEnabled}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, emailEnabled: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="push">Push Notifications</Label>
                  <p className="text-sm text-[--color-text-secondary]">
                    Send mobile push notifications
                  </p>
                </div>
                <Switch
                  id="push"
                  checked={settings.pushEnabled}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, pushEnabled: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="sms">SMS Notifications</Label>
                  <p className="text-sm text-[--color-text-secondary]">
                    Send notifications via SMS
                  </p>
                </div>
                <Switch
                  id="sms"
                  checked={settings.smsEnabled}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, smsEnabled: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto">Auto-send Enabled</Label>
                  <p className="text-sm text-[--color-text-secondary]">
                    Automatically send scheduled notifications
                  </p>
                </div>
                <Switch
                  id="auto"
                  checked={settings.autoSend}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, autoSend: checked })
                  }
                />
              </div>

              <Button
                onClick={() => toast.success('Settings saved successfully')}
                className="w-full"
              >
                Save Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
