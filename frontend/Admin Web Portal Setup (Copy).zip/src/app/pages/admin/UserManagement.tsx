import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import { Avatar, AvatarFallback } from '../../components/ui/avatar';
import { Users, UserPlus, Search, MoreHorizontal, Shield } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../../components/ui/dropdown-menu';
import { useState } from 'react';

// Aligned with database schema from ERD
interface User {
  id: string;
  name: string;
  email: string;
  role: 'Volunteer' | 'Organizer' | 'Admin' | 'Cashier';
  phone?: string;
  points: number; // Cached balance
  volunteer_qr_code?: string;
  status: 'active' | 'suspended' | 'inactive';
  created_at: string;
  updated_at?: string;
}

const mockUsers: User[] = [
  {
    id: '1',
    name: 'Grace Admin',
    email: 'admin@example.com',
    role: 'Admin',
    phone: '+65 9123 4567',
    status: 'active',
    points: 0,
    created_at: '2024-01-15T08:00:00Z',
  },
  {
    id: '2',
    name: 'Grace Organizer',
    email: 'organizer@example.com',
    role: 'Organizer',
    phone: '+65 9234 5678',
    status: 'active',
    points: 0,
    created_at: '2024-02-10T09:30:00Z',
  },
  {
    id: '3',
    name: 'Grace Cashier',
    email: 'cashier@example.com',
    role: 'Cashier',
    phone: '+65 9345 6789',
    status: 'active',
    points: 0,
    created_at: '2024-03-05T10:15:00Z',
  },
  {
    id: '4',
    name: 'John Volunteer',
    email: 'john.vol@example.com',
    role: 'Volunteer',
    phone: '+65 9456 7890',
    volunteer_qr_code: 'VOL-2024-001234',
    status: 'active',
    points: 2850,
    created_at: '2024-01-20T14:00:00Z',
  },
  {
    id: '5',
    name: 'Jane Volunteer',
    email: 'jane.vol@example.com',
    role: 'Volunteer',
    phone: '+65 9567 8901',
    volunteer_qr_code: 'VOL-2024-001235',
    status: 'active',
    points: 1950,
    created_at: '2024-02-15T11:30:00Z',
  },
  {
    id: '6',
    name: 'Bob Volunteer',
    email: 'bob.vol@example.com',
    role: 'Volunteer',
    phone: '+65 9678 9012',
    volunteer_qr_code: 'VOL-2024-001236',
    status: 'inactive',
    points: 500,
    created_at: '2024-03-20T16:45:00Z',
  },
  {
    id: '7',
    name: 'Sarah Organizer',
    email: 'sarah.org@example.com',
    role: 'Organizer',
    phone: '+65 9789 0123',
    status: 'active',
    points: 0,
    created_at: '2024-03-25T09:00:00Z',
  },
  {
    id: '8',
    name: 'Mike Cashier',
    email: 'mike.cashier@example.com',
    role: 'Cashier',
    phone: '+65 9890 1234',
    status: 'active',
    points: 0,
    created_at: '2024-04-01T13:20:00Z',
  },
];

export default function UserManagement() {
  const [users] = useState<User[]>(mockUsers);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Admin':
        return 'bg-red-600';
      case 'Organizer':
        return 'bg-blue-600';
      case 'Cashier':
        return 'bg-purple-600';
      case 'Volunteer':
        return 'bg-green-600';
      default:
        return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold text-slate-900">User Management</h1>
            <Badge>WEB-02</Badge>
          </div>
          <p className="text-slate-500 mt-1">
            Manage users, roles, and permissions
          </p>
        </div>
        <Button>
          <UserPlus className="h-4 w-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Users</CardDescription>
            <CardTitle className="text-3xl">{users.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Active Users</CardDescription>
            <CardTitle className="text-3xl text-green-600">
              {users.filter(u => u.status === 'active').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Volunteers</CardDescription>
            <CardTitle className="text-3xl text-green-600">
              {users.filter(u => u.role === 'Volunteer').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Points</CardDescription>
            <CardTitle className="text-3xl text-violet-600">
              {users.reduce((sum, u) => sum + u.points, 0).toLocaleString()}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>All Users</CardTitle>
              <CardDescription>View and manage system users</CardDescription>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Points</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-violet-600 text-white">
                          {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{user.name}</div>
                        {user.volunteer_qr_code && (
                          <div className="text-xs text-slate-500 font-mono">{user.volunteer_qr_code}</div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell className="text-sm text-slate-600">{user.phone || '-'}</TableCell>
                  <TableCell>
                    <Badge className={getRoleColor(user.role)}>
                      {user.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={user.status === 'active' ? 'bg-green-600' : user.status === 'suspended' ? 'bg-yellow-600' : 'bg-gray-600'}>
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-semibold text-violet-600">
                    {user.points.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-sm text-slate-600">
                    {new Date(user.created_at).toLocaleDateString('en-SG')}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>Edit User</DropdownMenuItem>
                        <DropdownMenuItem>Change Role</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          Deactivate
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
