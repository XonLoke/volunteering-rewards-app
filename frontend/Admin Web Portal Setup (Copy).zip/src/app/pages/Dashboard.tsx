import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import {
  Ticket,
  Users,
  TrendingUp,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  Gift,
  Hash,
  FileText,
  Smartphone
} from 'lucide-react';
import { Link } from 'react-router';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const stats = [
  {
    title: 'Active Coupons',
    value: '1,234',
    change: '+12.5%',
    trend: 'up',
    icon: Ticket,
    color: 'text-blue-600 bg-blue-100',
  },
  {
    title: 'Total Redemptions',
    value: '5,678',
    change: '+8.2%',
    trend: 'up',
    icon: Award,
    color: 'text-green-600 bg-green-100',
  },
  {
    title: 'Active Users',
    value: '2,345',
    change: '-2.4%',
    trend: 'down',
    icon: Users,
    color: 'text-purple-600 bg-purple-100',
  },
  {
    title: 'Revenue Impact',
    value: '$45.2K',
    change: '+15.3%',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-orange-600 bg-orange-100',
  },
];

const quickLinks = [
  { title: 'Coupon Management', href: '/rewards/coupons', icon: Ticket, badge: 'REW-W01', description: 'Create and manage promotional coupons' },
  { title: 'PIN Verification', href: '/rewards/pin-verify', icon: Hash, badge: 'REW-W02', description: 'Verify customer PIN codes' },
  { title: 'Audit Log', href: '/rewards/audit', icon: FileText, badge: 'REW-W03', description: 'View system activity logs' },
  { title: 'Mobile Rewards', href: '/rewards/mobile/list', icon: Smartphone, badge: 'REW-M01', description: 'Mobile rewards interface' },
];

const recentActivity = [
  { action: 'Coupon SUMMER2024 created', user: 'Grace Admin', time: '2 minutes ago', type: 'create' },
  { action: 'PIN verified for user #1234', user: 'Grace Staff', time: '15 minutes ago', type: 'verify' },
  { action: 'Reward redeemed by customer', user: 'System', time: '1 hour ago', type: 'redeem' },
  { action: 'Coupon SPRING2024 expired', user: 'System', time: '2 hours ago', type: 'expire' },
  { action: 'New user registered', user: 'System', time: '3 hours ago', type: 'register' },
];

const revenueData = [
  { month: 'Jan', revenue: 24500, redemptions: 145 },
  { month: 'Feb', revenue: 28200, redemptions: 168 },
  { month: 'Mar', revenue: 32100, redemptions: 192 },
  { month: 'Apr', revenue: 35800, redemptions: 215 },
  { month: 'May', revenue: 42300, redemptions: 248 },
  { month: 'Jun', revenue: 45200, redemptions: 267 },
];

const categoryData = [
  { category: 'Electronics', count: 342, revenue: 18500 },
  { category: 'Fashion', count: 289, revenue: 12800 },
  { category: 'Food & Drink', count: 456, revenue: 8900 },
  { category: 'Travel', count: 178, revenue: 25400 },
  { category: 'Entertainment', count: 234, revenue: 9600 },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-1">
          Overview of your rewards and admin portal - WEB-01 Implementation
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-lg ${stat.color}`}>
                  <Icon className="h-4 w-4" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="flex items-center gap-1 mt-1">
                  {stat.trend === 'up' ? (
                    <ArrowUpRight className="h-4 w-4 text-green-600" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 text-red-600" />
                  )}
                  <span
                    className={`text-sm font-medium ${
                      stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}
                  >
                    {stat.change}
                  </span>
                  <span className="text-sm text-slate-500">vs last month</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Links */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link key={link.href} to={link.href}>
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="p-2 bg-violet-100 rounded-lg">
                        <Icon className="h-5 w-5 text-violet-600" />
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {link.badge}
                      </Badge>
                    </div>
                    <CardTitle className="text-base mt-3">{link.title}</CardTitle>
                    <CardDescription className="text-xs">
                      {link.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Analytics Charts */}
      <Card>
        <CardHeader>
          <CardTitle>Analytics Overview</CardTitle>
          <CardDescription>Revenue and redemption trends</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="revenue" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="revenue">Revenue Trend</TabsTrigger>
              <TabsTrigger value="category">By Category</TabsTrigger>
            </TabsList>
            <TabsContent value="revenue">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="revenue"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    name="Revenue ($)"
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="redemptions"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    name="Redemptions"
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>
            <TabsContent value="category">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={categoryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" fill="#8b5cf6" name="Redemptions" />
                  <Bar dataKey="revenue" fill="#3b82f6" name="Revenue ($)" />
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest actions in your admin portal</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-4 pb-4 border-b last:border-0 last:pb-0">
                  <div className="p-2 bg-slate-100 rounded-lg mt-1">
                    <Gift className="h-4 w-4 text-slate-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900">{activity.action}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      by {activity.user} · {activity.time}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {activity.type}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Current system health</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">API Status</span>
              <Badge className="bg-green-600">Operational</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Database</span>
              <Badge className="bg-green-600">Healthy</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Cache</span>
              <Badge className="bg-green-600">Online</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Background Jobs</span>
              <Badge className="bg-yellow-600">3 Pending</Badge>
            </div>
            <Button variant="outline" className="w-full mt-4">
              View Details
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Rewards */}
      <Card>
        <CardHeader>
          <CardTitle>Top Performing Rewards</CardTitle>
          <CardDescription>Most redeemed rewards this month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: '50% Off Electronics', redemptions: 342, trend: '+12%' },
              { name: 'Free Shipping Voucher', redemptions: 289, trend: '+8%' },
              { name: '$20 Dining Credit', redemptions: 256, trend: '+15%' },
              { name: 'Movie Ticket Discount', redemptions: 234, trend: '+5%' },
              { name: 'Gym Membership Deal', redemptions: 198, trend: '+18%' },
            ].map((reward, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-violet-100 text-violet-600 font-semibold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{reward.name}</p>
                    <p className="text-xs text-slate-500">{reward.redemptions} redemptions</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-green-600">
                  {reward.trend}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
