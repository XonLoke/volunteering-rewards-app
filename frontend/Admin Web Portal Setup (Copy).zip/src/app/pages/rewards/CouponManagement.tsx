import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Badge } from '../../components/ui/badge';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Textarea } from '../../components/ui/textarea';
import { Checkbox } from '../../components/ui/checkbox';
import { Plus, Search, Edit, Trash2, Copy, MoreHorizontal, Filter, Download, Trash, CheckSquare } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
} from '../../components/ui/dropdown-menu';
import { toast } from 'sonner';

// Aligned with database schema from ERD
interface Coupon {
  id: string;
  title: string;
  description: string;
  image_url?: string;
  points_required: number;
  quantity: number;
  redeemed: number; // Track how many have been redeemed
  expiry_date: string;
  status: 'active' | 'inactive' | 'depleted';
  created_by: number;
  created_at: string;
  updated_at?: string;
}

const mockCoupons: Coupon[] = [
  {
    id: '1',
    title: '$50 FairPrice Voucher',
    description: 'Redeemable at any FairPrice outlet for groceries and essentials',
    points_required: 500,
    quantity: 100,
    redeemed: 45,
    expiry_date: '2024-12-31T23:59:59Z',
    status: 'active',
    created_by: 1,
    created_at: '2024-01-15T08:00:00Z',
  },
  {
    id: '2',
    title: 'Free Movie Tickets (2x)',
    description: 'Two complimentary movie tickets at any Golden Village cinema',
    points_required: 800,
    quantity: 50,
    redeemed: 23,
    expiry_date: '2024-11-30T23:59:59Z',
    status: 'active',
    created_by: 1,
    created_at: '2024-02-01T09:00:00Z',
  },
  {
    id: '3',
    title: '$20 Grab Voucher',
    description: 'Use for Grab rides or GrabFood orders',
    points_required: 200,
    quantity: 200,
    redeemed: 189,
    expiry_date: '2024-08-31T23:59:59Z',
    status: 'active',
    created_by: 1,
    created_at: '2024-03-10T10:30:00Z',
  },
  {
    id: '4',
    title: 'Starbucks Coffee Voucher',
    description: 'One free tall-size beverage at any Starbucks outlet',
    points_required: 150,
    quantity: 100,
    redeemed: 100,
    expiry_date: '2024-06-30T23:59:59Z',
    status: 'depleted',
    created_by: 1,
    created_at: '2024-01-20T11:00:00Z',
  },
  {
    id: '5',
    title: 'Gym Membership (1 Month)',
    description: 'One month free membership at ActiveSG gyms',
    points_required: 1200,
    quantity: 30,
    redeemed: 12,
    expiry_date: '2024-12-31T23:59:59Z',
    status: 'active',
    created_by: 1,
    created_at: '2024-04-01T13:00:00Z',
  },
  {
    id: '6',
    title: 'Zoo Tickets (Family of 4)',
    description: 'Four tickets to Singapore Zoo - perfect for family outing',
    points_required: 600,
    quantity: 25,
    redeemed: 8,
    expiry_date: '2024-10-31T23:59:59Z',
    status: 'active',
    created_by: 1,
    created_at: '2024-05-01T14:00:00Z',
  },
];

export default function CouponManagement() {
  const [coupons, setCoupons] = useState<Coupon[]>(mockCoupons);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedCoupons, setSelectedCoupons] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string[]>(['active', 'inactive', 'depleted']);

  const filteredCoupons = coupons.filter(coupon => {
    const matchesSearch = coupon.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coupon.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter.includes(coupon.status);
    return matchesSearch && matchesStatus;
  });

  const toggleCouponSelection = (id: string) => {
    setSelectedCoupons(prev =>
      prev.includes(id) ? prev.filter(cid => cid !== id) : [...prev, id]
    );
  };

  const toggleAllCoupons = () => {
    if (selectedCoupons.length === filteredCoupons.length) {
      setSelectedCoupons([]);
    } else {
      setSelectedCoupons(filteredCoupons.map(c => c.id));
    }
  };

  const handleBulkDelete = () => {
    setCoupons(prev => prev.filter(c => !selectedCoupons.includes(c.id)));
    setSelectedCoupons([]);
    toast.success(`Deleted ${selectedCoupons.length} coupons`);
  };

  const handleBulkExport = () => {
    toast.success(`Exporting ${selectedCoupons.length} coupons...`);
  };

  const handleExportAll = () => {
    toast.success('Exporting all coupons...');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-600';
      case 'inactive':
        return 'bg-gray-600';
      case 'depleted':
        return 'bg-red-600';
      default:
        return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold text-slate-900">Coupon Management</h1>
            <Badge>REW-W01</Badge>
          </div>
          <p className="text-slate-500 mt-1">
            Create and manage reward coupons redeemable by volunteers
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Coupon
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Coupon</DialogTitle>
              <DialogDescription>
                Add a new reward coupon for volunteers to redeem
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Coupon Title</Label>
                <Input id="title" placeholder="$50 FairPrice Voucher" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what the coupon offers and where it can be used..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="points">Points Required</Label>
                  <Input id="points" type="number" placeholder="500" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity Available</Label>
                  <Input id="quantity" type="number" placeholder="100" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiry">Expiry Date</Label>
                <Input id="expiry" type="date" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="image">Image URL (Optional)</Label>
                <Input id="image" type="url" placeholder="https://example.com/image.jpg" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsCreateDialogOpen(false)}>
                Create Coupon
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Coupons</CardDescription>
            <CardTitle className="text-3xl">{coupons.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Active Coupons</CardDescription>
            <CardTitle className="text-3xl">
              {coupons.filter(c => c.status === 'active').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Redeemed</CardDescription>
            <CardTitle className="text-3xl">
              {coupons.reduce((sum, c) => sum + c.redeemed, 0)}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Depleted</CardDescription>
            <CardTitle className="text-3xl">
              {coupons.filter(c => c.status === 'depleted').length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Coupons Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>All Coupons</CardTitle>
              <CardDescription>Manage reward coupons for volunteers</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {selectedCoupons.length > 0 && (
                <div className="flex items-center gap-2 mr-2">
                  <Badge variant="secondary">{selectedCoupons.length} selected</Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleBulkExport}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleBulkDelete}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </div>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5 text-sm font-semibold">Status</div>
                  <DropdownMenuCheckboxItem
                    checked={statusFilter.includes('active')}
                    onCheckedChange={(checked) =>
                      setStatusFilter(prev =>
                        checked ? [...prev, 'active'] : prev.filter(s => s !== 'active')
                      )
                    }
                  >
                    Active
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={statusFilter.includes('inactive')}
                    onCheckedChange={(checked) =>
                      setStatusFilter(prev =>
                        checked ? [...prev, 'inactive'] : prev.filter(s => s !== 'inactive')
                      )
                    }
                  >
                    Inactive
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={statusFilter.includes('depleted')}
                    onCheckedChange={(checked) =>
                      setStatusFilter(prev =>
                        checked ? [...prev, 'depleted'] : prev.filter(s => s !== 'depleted')
                      )
                    }
                  >
                    Depleted
                  </DropdownMenuCheckboxItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search coupons..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-64"
                />
              </div>
              <Button variant="outline" size="sm" onClick={handleExportAll}>
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedCoupons.length === filteredCoupons.length && filteredCoupons.length > 0}
                    onCheckedChange={toggleAllCoupons}
                  />
                </TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Points</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Redeemed / Available</TableHead>
                <TableHead>Expiry Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCoupons.map((coupon) => (
                <TableRow key={coupon.id}>
                  <TableCell>
                    <Checkbox
                      checked={selectedCoupons.includes(coupon.id)}
                      onCheckedChange={() => toggleCouponSelection(coupon.id)}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{coupon.title}</TableCell>
                  <TableCell className="text-sm text-slate-600 max-w-xs truncate">
                    {coupon.description}
                  </TableCell>
                  <TableCell className="font-semibold text-violet-600">
                    {coupon.points_required} pts
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(coupon.status)}>
                      {coupon.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">{coupon.redeemed}</span>
                    <span className="text-slate-500"> / {coupon.quantity}</span>
                  </TableCell>
                  <TableCell className="text-sm">
                    {new Date(coupon.expiry_date).toLocaleDateString('en-SG')}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Copy className="h-4 w-4 mr-2" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
