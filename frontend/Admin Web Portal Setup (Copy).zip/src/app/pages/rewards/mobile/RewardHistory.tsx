import { useState } from 'react';
import { Card, CardContent } from '../../../components/ui/card';
import { Badge } from '../../../components/ui/badge';
import { Button } from '../../../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../components/ui/tabs';
import { 
  ArrowLeft, 
  Gift, 
  CheckCircle,
  Clock,
  XCircle,
  Calendar,
  TrendingUp
} from 'lucide-react';
import { Link } from 'react-router';

interface HistoryItem {
  id: string;
  rewardName: string;
  points: number;
  status: 'redeemed' | 'used' | 'expired';
  date: string;
  pin?: string;
  expiryDate?: string;
}

const mockHistory: HistoryItem[] = [
  {
    id: '1',
    rewardName: 'Free Coffee Voucher',
    points: 500,
    status: 'redeemed',
    date: '2024-05-16',
    pin: '847352',
    expiryDate: '2024-06-15',
  },
  {
    id: '2',
    rewardName: '20% Shopping Discount',
    points: 1000,
    status: 'used',
    date: '2024-05-10',
    pin: '123456',
  },
  {
    id: '3',
    rewardName: 'Free Pizza',
    points: 800,
    status: 'used',
    date: '2024-05-05',
    pin: '789012',
  },
  {
    id: '4',
    rewardName: 'Movie Ticket',
    points: 1500,
    status: 'expired',
    date: '2024-04-20',
    pin: '456789',
  },
  {
    id: '5',
    rewardName: 'Free Delivery',
    points: 300,
    status: 'used',
    date: '2024-04-15',
    pin: '234567',
  },
];

const pointsEarned = [
  { date: '2024-05-15', points: 250, description: 'Purchase bonus' },
  { date: '2024-05-12', points: 500, description: 'Referral reward' },
  { date: '2024-05-10', points: 100, description: 'Daily check-in' },
  { date: '2024-05-08', points: 750, description: 'Survey completion' },
  { date: '2024-05-05', points: 300, description: 'Birthday bonus' },
];

export default function RewardHistory() {
  const [activeTab, setActiveTab] = useState('redeemed');

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'redeemed':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'used':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'expired':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'redeemed':
        return 'bg-yellow-600';
      case 'used':
        return 'bg-green-600';
      case 'expired':
        return 'bg-red-600';
      default:
        return 'bg-gray-600';
    }
  };

  const redeemedItems = mockHistory.filter(item => item.status === 'redeemed');
  const usedItems = mockHistory.filter(item => item.status === 'used');
  const expiredItems = mockHistory.filter(item => item.status === 'expired');

  const totalPointsSpent = mockHistory.reduce((sum, item) => sum + item.points, 0);
  const totalPointsEarned = pointsEarned.reduce((sum, item) => sum + item.points, 0);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-slate-900">Reward History</h1>
          <Badge>REW-M04</Badge>
        </div>
        <p className="text-slate-500 mt-1">
          Mobile view: Track your redemption and points history
        </p>
      </div>

      {/* Mobile Preview Container */}
      <div className="flex justify-center">
        <div className="w-full max-w-md border-4 border-slate-900 rounded-[3rem] overflow-hidden shadow-2xl bg-white">
          {/* Mobile Screen */}
          <div className="bg-white h-[700px] overflow-y-auto">
            {/* Mobile Header */}
            <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white p-4 sticky top-0 z-10">
              <div className="flex items-center gap-3 mb-4">
                <Link to="/rewards/mobile/list">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <h2 className="font-semibold">My History</h2>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="p-4 -mt-2 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Card className="bg-gradient-to-br from-violet-600 to-purple-600 border-0 text-white">
                  <CardContent className="p-4">
                    <p className="text-xs opacity-90 mb-1">Points Spent</p>
                    <p className="text-2xl font-bold">{totalPointsSpent.toLocaleString()}</p>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-green-600 to-emerald-600 border-0 text-white">
                  <CardContent className="p-4">
                    <p className="text-xs opacity-90 mb-1">Points Earned</p>
                    <p className="text-2xl font-bold">{totalPointsEarned.toLocaleString()}</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Tabs */}
            <div className="px-4 pb-4">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full grid grid-cols-3">
                  <TabsTrigger value="redeemed" className="text-xs">
                    Active ({redeemedItems.length})
                  </TabsTrigger>
                  <TabsTrigger value="used" className="text-xs">
                    Used ({usedItems.length})
                  </TabsTrigger>
                  <TabsTrigger value="points" className="text-xs">
                    Points
                  </TabsTrigger>
                </TabsList>

                {/* Active/Redeemed Rewards */}
                <TabsContent value="redeemed" className="mt-4 space-y-3">
                  {redeemedItems.length > 0 ? (
                    redeemedItems.map((item) => (
                      <Card key={item.id} className="border-2 border-yellow-200 bg-yellow-50">
                        <CardContent className="p-4">
                          <div className="flex gap-3">
                            <div className="p-3 bg-white rounded-xl">
                              <Gift className="h-6 w-6 text-violet-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-1">
                                <h4 className="font-semibold text-slate-900">{item.rewardName}</h4>
                                <Badge className={getStatusColor(item.status)}>
                                  Active
                                </Badge>
                              </div>
                              <p className="text-xs text-slate-600 mb-2">
                                PIN: <span className="font-mono font-semibold">{item.pin}</span>
                              </p>
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-slate-500">
                                  Redeemed on {item.date}
                                </span>
                                <span className="text-violet-600 font-semibold">
                                  {item.points} pts
                                </span>
                              </div>
                              {item.expiryDate && (
                                <div className="mt-2 flex items-center gap-1 text-xs text-orange-600">
                                  <Clock className="h-3 w-3" />
                                  <span>Expires {item.expiryDate}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <Clock className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                      <p className="text-slate-500 text-sm">No active rewards</p>
                    </div>
                  )}
                </TabsContent>

                {/* Used Rewards */}
                <TabsContent value="used" className="mt-4 space-y-3">
                  {usedItems.map((item) => (
                    <Card key={item.id}>
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <div className="p-3 bg-green-100 rounded-xl">
                            {getStatusIcon(item.status)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <h4 className="font-semibold text-slate-900">{item.rewardName}</h4>
                              <Badge className={getStatusColor(item.status)}>
                                Used
                              </Badge>
                            </div>
                            <p className="text-xs text-slate-600 mb-2">
                              PIN: <span className="font-mono">{item.pin}</span>
                            </p>
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-500">
                                Used on {item.date}
                              </span>
                              <span className="text-slate-600 font-semibold">
                                {item.points} pts
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                {/* Points History */}
                <TabsContent value="points" className="mt-4 space-y-3">
                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-green-600" />
                      Recent Points Earned
                    </h3>
                    <div className="space-y-2">
                      {pointsEarned.map((item, index) => (
                        <Card key={index}>
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="p-2 bg-green-100 rounded-lg">
                                  <TrendingUp className="h-4 w-4 text-green-600" />
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-slate-900">
                                    {item.description}
                                  </p>
                                  <p className="text-xs text-slate-500">
                                    {item.date}
                                  </p>
                                </div>
                              </div>
                              <span className="text-lg font-bold text-green-600">
                                +{item.points}
                              </span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
                      <Gift className="h-4 w-4 text-red-600" />
                      Recent Points Spent
                    </h3>
                    <div className="space-y-2">
                      {mockHistory.slice(0, 3).map((item) => (
                        <Card key={item.id}>
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="p-2 bg-red-100 rounded-lg">
                                  <Gift className="h-4 w-4 text-red-600" />
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-slate-900">
                                    {item.rewardName}
                                  </p>
                                  <p className="text-xs text-slate-500">
                                    {item.date}
                                  </p>
                                </div>
                              </div>
                              <span className="text-lg font-bold text-red-600">
                                -{item.points}
                              </span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
