import { Card, CardContent } from '../../../components/ui/card';
import { Badge } from '../../../components/ui/badge';
import { Button } from '../../../components/ui/button';
import { Progress } from '../../../components/ui/progress';
import { 
  ArrowLeft, 
  Gift, 
  MapPin, 
  Clock, 
  Star,
  Share2,
  Heart,
  Info
} from 'lucide-react';
import { Link } from 'react-router';

// Mock reward data
const reward = {
  id: '1',
  name: 'Free Coffee Voucher',
  description: 'Get a free coffee at any participating café. Valid for all sizes and coffee varieties.',
  longDescription: 'Enjoy a complimentary coffee of your choice at any of our partner cafés. This reward includes all sizes from small to large and covers espresso, latte, cappuccino, and more. Simply show your redemption code at the counter.',
  points: 500,
  category: 'food',
  availability: 85,
  featured: true,
  validUntil: '2024-12-31',
  locations: '150+ participating cafés',
  terms: [
    'Valid for one-time use only',
    'Cannot be combined with other offers',
    'Not redeemable for cash',
    'Subject to availability',
    'Must be used within 30 days of redemption',
  ],
  partnerLogos: ['Starbucks', 'Costa Coffee', 'Dunkin', 'Tim Hortons'],
};

const userPoints = 2500;

export default function RewardDetails() {
  const canRedeem = userPoints >= reward.points;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-slate-900">Reward Details</h1>
          <Badge>REW-M02</Badge>
        </div>
        <p className="text-slate-500 mt-1">
          Mobile view: Detailed reward information
        </p>
      </div>

      {/* Mobile Preview Container */}
      <div className="flex justify-center">
        <div className="w-full max-w-md border-4 border-slate-900 rounded-[3rem] overflow-hidden shadow-2xl bg-white">
          {/* Mobile Screen */}
          <div className="bg-white h-[700px] overflow-y-auto">
            {/* Mobile Header */}
            <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white p-4 sticky top-0 z-10">
              <div className="flex items-center justify-between">
                <Link to="/rewards/mobile/list">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <h2 className="font-semibold">Reward Details</h2>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                    <Share2 className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                    <Heart className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Reward Image */}
            <div className="bg-gradient-to-br from-violet-100 to-purple-100 h-48 flex items-center justify-center">
              <div className="p-6 bg-white rounded-3xl shadow-lg">
                <Gift className="h-20 w-20 text-violet-600" />
              </div>
            </div>

            {/* Reward Content */}
            <div className="p-6 space-y-6">
              {/* Title and Points */}
              <div>
                <div className="flex items-start justify-between mb-2">
                  <h1 className="text-2xl font-bold text-slate-900">{reward.name}</h1>
                  {reward.featured && (
                    <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
                  )}
                </div>
                <p className="text-slate-600 mb-4">{reward.description}</p>
                
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-violet-600">{reward.points}</span>
                    <span className="text-slate-500">points</span>
                  </div>
                  <Badge variant="outline" className="bg-orange-100 text-orange-700">
                    {reward.category}
                  </Badge>
                </div>

                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-slate-600">Your Points</span>
                    <span className="font-semibold text-slate-900">{userPoints.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-slate-600">Required</span>
                    <span className="font-semibold text-slate-900">{reward.points.toLocaleString()}</span>
                  </div>
                  {canRedeem && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">After Redemption</span>
                      <span className="font-semibold text-green-600">
                        {(userPoints - reward.points).toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Details */}
              <div className="space-y-4">
                <h3 className="font-semibold text-slate-900">Reward Details</h3>
                
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <MapPin className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">Locations</p>
                    <p className="text-sm text-slate-600">{reward.locations}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Clock className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">Valid Until</p>
                    <p className="text-sm text-slate-600">{reward.validUntil}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <Info className="h-4 w-4 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-900 mb-1">Availability</p>
                    <Progress value={reward.availability} className="h-2 mb-1" />
                    <p className="text-xs text-slate-600">{reward.availability}% available</p>
                  </div>
                </div>
              </div>

              {/* About */}
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">About This Reward</h3>
                <p className="text-sm text-slate-600">{reward.longDescription}</p>
              </div>

              {/* Terms and Conditions */}
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">Terms & Conditions</h3>
                <ul className="space-y-2">
                  {reward.terms.map((term, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm text-slate-600">
                      <span className="text-violet-600 mt-1">•</span>
                      <span>{term}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Partner Logos */}
              <div>
                <h3 className="font-semibold text-slate-900 mb-3">Partner Locations</h3>
                <div className="grid grid-cols-2 gap-2">
                  {reward.partnerLogos.map((partner, index) => (
                    <div
                      key={index}
                      className="p-3 bg-slate-50 rounded-lg text-center text-sm font-medium text-slate-700"
                    >
                      {partner}
                    </div>
                  ))}
                </div>
              </div>

              {/* Redeem Button */}
              <div className="sticky bottom-0 -mx-6 -mb-6 p-4 bg-white border-t">
                <Link to="/rewards/mobile/redeem">
                  <Button
                    className="w-full py-6 text-lg"
                    disabled={!canRedeem}
                  >
                    {canRedeem ? (
                      <>Redeem for {reward.points} Points</>
                    ) : (
                      <>Need {reward.points - userPoints} More Points</>
                    )}
                  </Button>
                </Link>
                {!canRedeem && (
                  <p className="text-xs text-center text-slate-500 mt-2">
                    Keep earning points to unlock this reward
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
