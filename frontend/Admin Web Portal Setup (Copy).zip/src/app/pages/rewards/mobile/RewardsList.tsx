import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../../components/ui/card';
import { Badge } from '../../../components/ui/badge';
import { Button } from '../../../components/ui/button';
import { Input } from '../../../components/ui/input';
import { Progress } from '../../../components/ui/progress';
import { Gift, Star, Zap, Search, TrendingUp } from 'lucide-react';
import { Link } from 'react-router';

interface Reward {
  id: string;
  name: string;
  description: string;
  points: number;
  category: 'food' | 'shopping' | 'entertainment' | 'travel';
  availability: number;
  trending?: boolean;
  featured?: boolean;
}

const mockRewards: Reward[] = [
  {
    id: '1',
    name: 'Free Coffee Voucher',
    description: 'Get a free coffee at any participating café',
    points: 500,
    category: 'food',
    availability: 85,
    featured: true,
  },
  {
    id: '2',
    name: '20% Shopping Discount',
    description: '20% off on your next purchase at partner stores',
    points: 1000,
    category: 'shopping',
    availability: 60,
    trending: true,
  },
  {
    id: '3',
    name: 'Movie Ticket',
    description: 'Free movie ticket for any show at selected theaters',
    points: 1500,
    category: 'entertainment',
    availability: 42,
  },
  {
    id: '4',
    name: 'Free Pizza',
    description: 'Get a medium pizza free from partner restaurants',
    points: 800,
    category: 'food',
    availability: 73,
    trending: true,
  },
  {
    id: '5',
    name: '$50 Travel Voucher',
    description: 'Travel voucher applicable on flights and hotels',
    points: 3000,
    category: 'travel',
    availability: 28,
    featured: true,
  },
  {
    id: '6',
    name: 'Spa Day Pass',
    description: 'One day pass to premium spa and wellness center',
    points: 2500,
    category: 'entertainment',
    availability: 15,
  },
];

export default function RewardsList() {
  const [rewards, setRewards] = useState<Reward[]>(mockRewards);
  const [searchQuery, setSearchQuery] = useState('');
  const [userPoints] = useState(2500);

  const filteredRewards = rewards.filter(reward =>
    reward.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    reward.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'food':
        return 'bg-orange-100 text-orange-700';
      case 'shopping':
        return 'bg-blue-100 text-blue-700';
      case 'entertainment':
        return 'bg-purple-100 text-purple-700';
      case 'travel':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-slate-900">Rewards Catalog</h1>
          <Badge>REW-M01</Badge>
        </div>
        <p className="text-slate-500 mt-1">
          Mobile view: Browse and redeem available rewards
        </p>
      </div>

      {/* Mobile Preview Container */}
      <div className="flex justify-center">
        <div className="w-full max-w-md border-4 border-slate-900 rounded-[3rem] overflow-hidden shadow-2xl bg-white">
          {/* Mobile Screen */}
          <div className="bg-white h-[700px] overflow-y-auto">
            {/* Mobile Header */}
            <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white p-6 pb-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-sm opacity-90">Your Points</p>
                  <h2 className="text-3xl font-bold">{userPoints.toLocaleString()}</h2>
                </div>
                <div className="p-3 bg-white/20 rounded-2xl backdrop-blur">
                  <Gift className="h-6 w-6" />
                </div>
              </div>
              
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search rewards..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-white/90 border-0"
                />
              </div>
            </div>

            {/* Rewards List */}
            <div className="p-4 space-y-4 -mt-4">
              {/* Featured Rewards */}
              {filteredRewards.some(r => r.featured) && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-600 mb-3 flex items-center gap-2">
                    <Star className="h-4 w-4 text-yellow-600" />
                    Featured Rewards
                  </h3>
                  {filteredRewards
                    .filter(r => r.featured)
                    .map((reward) => (
                      <Card key={reward.id} className="mb-3 overflow-hidden">
                        <CardContent className="p-4">
                          <div className="flex gap-3">
                            <div className="p-3 bg-violet-100 rounded-xl flex-shrink-0">
                              <Gift className="h-6 w-6 text-violet-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-1">
                                <h4 className="font-semibold text-slate-900">{reward.name}</h4>
                                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 flex-shrink-0" />
                              </div>
                              <p className="text-sm text-slate-600 mb-3">{reward.description}</p>
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-violet-600">{reward.points}</span>
                                    <span className="text-xs text-slate-500">points</span>
                                  </div>
                                  <Badge variant="outline" className={`${getCategoryColor(reward.category)} text-xs mt-1`}>
                                    {reward.category}
                                  </Badge>
                                </div>
                                <Link to={`/rewards/mobile/details?id=${reward.id}`}>
                                  <Button size="sm" disabled={userPoints < reward.points}>
                                    View Details
                                  </Button>
                                </Link>
                              </div>
                              <div className="mt-3">
                                <div className="flex justify-between text-xs mb-1">
                                  <span className="text-slate-500">Availability</span>
                                  <span className="text-slate-700 font-medium">{reward.availability}%</span>
                                </div>
                                <Progress value={reward.availability} className="h-1.5" />
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}

              {/* Trending Rewards */}
              {filteredRewards.some(r => r.trending) && (
                <div>
                  <h3 className="text-sm font-semibold text-slate-600 mb-3 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-red-600" />
                    Trending Now
                  </h3>
                  {filteredRewards
                    .filter(r => r.trending && !r.featured)
                    .map((reward) => (
                      <Card key={reward.id} className="mb-3">
                        <CardContent className="p-4">
                          <div className="flex gap-3">
                            <div className="p-3 bg-blue-100 rounded-xl flex-shrink-0">
                              <Zap className="h-6 w-6 text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-1">
                                <h4 className="font-semibold text-slate-900">{reward.name}</h4>
                                <Badge className="bg-red-600 text-xs">Trending</Badge>
                              </div>
                              <p className="text-sm text-slate-600 mb-3">{reward.description}</p>
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-violet-600">{reward.points}</span>
                                    <span className="text-xs text-slate-500">points</span>
                                  </div>
                                  <Badge variant="outline" className={`${getCategoryColor(reward.category)} text-xs mt-1`}>
                                    {reward.category}
                                  </Badge>
                                </div>
                                <Link to={`/rewards/mobile/details?id=${reward.id}`}>
                                  <Button size="sm" variant="outline">
                                    View
                                  </Button>
                                </Link>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              )}

              {/* All Other Rewards */}
              <div>
                <h3 className="text-sm font-semibold text-slate-600 mb-3">All Rewards</h3>
                {filteredRewards
                  .filter(r => !r.featured && !r.trending)
                  .map((reward) => (
                    <Card key={reward.id} className="mb-3">
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <div className="p-3 bg-slate-100 rounded-xl flex-shrink-0">
                            <Gift className="h-6 w-6 text-slate-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-slate-900 mb-1">{reward.name}</h4>
                            <p className="text-sm text-slate-600 mb-3">{reward.description}</p>
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-violet-600">{reward.points}</span>
                                  <span className="text-xs text-slate-500">points</span>
                                </div>
                                <Badge variant="outline" className={`${getCategoryColor(reward.category)} text-xs mt-1`}>
                                  {reward.category}
                                </Badge>
                              </div>
                              <Link to={`/rewards/mobile/details?id=${reward.id}`}>
                                <Button size="sm" variant="outline">
                                  View
                                </Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
