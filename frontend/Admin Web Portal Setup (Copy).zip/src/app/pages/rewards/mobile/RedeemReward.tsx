import { useState } from 'react';
import { Card, CardContent } from '../../../components/ui/card';
import { Badge } from '../../../components/ui/badge';
import { Button } from '../../../components/ui/button';
import { Alert, AlertDescription } from '../../../components/ui/alert';
import { 
  ArrowLeft, 
  Gift, 
  CheckCircle,
  Copy,
  MapPin,
  Clock,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router';

export default function RedeemReward() {
  const [isRedeemed, setIsRedeemed] = useState(false);
  const [pinCode] = useState('847352');
  const [expiresIn] = useState('29 days 14 hours');

  const handleRedeem = () => {
    setIsRedeemed(true);
  };

  const handleCopyPin = () => {
    navigator.clipboard.writeText(pinCode);
    alert('PIN code copied to clipboard!');
  };

  if (!isRedeemed) {
    return (
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold text-slate-900">Redeem Reward</h1>
            <Badge>REW-M03</Badge>
          </div>
          <p className="text-slate-500 mt-1">
            Mobile view: Confirm and redeem your reward
          </p>
        </div>

        {/* Mobile Preview Container */}
        <div className="flex justify-center">
          <div className="w-full max-w-md border-4 border-slate-900 rounded-[3rem] overflow-hidden shadow-2xl bg-white">
            {/* Mobile Screen */}
            <div className="bg-white h-[700px] overflow-y-auto">
              {/* Mobile Header */}
              <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white p-4 sticky top-0 z-10">
                <div className="flex items-center gap-3">
                  <Link to="/rewards/mobile/details">
                    <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                      <ArrowLeft className="h-5 w-5" />
                    </Button>
                  </Link>
                  <h2 className="font-semibold">Confirm Redemption</h2>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-6">
                {/* Reward Summary */}
                <Card className="border-2 border-violet-200 bg-violet-50">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="p-4 bg-white rounded-2xl shadow-sm">
                        <Gift className="h-12 w-12 text-violet-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg text-slate-900 mb-1">
                          Free Coffee Voucher
                        </h3>
                        <p className="text-sm text-slate-600 mb-3">
                          Valid at 150+ participating cafés
                        </p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-violet-600">500</span>
                          <span className="text-slate-500">points</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Points Balance */}
                <div className="bg-slate-50 rounded-xl p-6 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Current Balance</span>
                    <span className="font-semibold text-slate-900">2,500 points</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Redemption Cost</span>
                    <span className="font-semibold text-red-600">-500 points</span>
                  </div>
                  <div className="h-px bg-slate-200" />
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-900">New Balance</span>
                    <span className="font-bold text-green-600">2,000 points</span>
                  </div>
                </div>

                {/* Important Information */}
                <Alert>
                  <Sparkles className="h-4 w-4" />
                  <AlertDescription>
                    <p className="font-medium mb-2">Before you redeem:</p>
                    <ul className="text-sm space-y-1 text-slate-600">
                      <li>• Your PIN code will be generated instantly</li>
                      <li>• Valid for 30 days from redemption</li>
                      <li>• Cannot be reversed once redeemed</li>
                      <li>• Show PIN code at partner location</li>
                    </ul>
                  </AlertDescription>
                </Alert>

                {/* Terms */}
                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Terms & Conditions</h4>
                  <div className="text-sm text-slate-600 space-y-1">
                    <p>✓ Valid for one-time use only</p>
                    <p>✓ Cannot be combined with other offers</p>
                    <p>✓ Not redeemable for cash</p>
                    <p>✓ Subject to availability</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3 sticky bottom-0 -mx-6 -mb-6 p-6 bg-white border-t">
                  <Button
                    className="w-full py-6 text-lg"
                    onClick={handleRedeem}
                  >
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Confirm Redemption
                  </Button>
                  <Link to="/rewards/mobile/details" className="block">
                    <Button variant="outline" className="w-full">
                      Cancel
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Success State
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-slate-900">Redeem Reward</h1>
          <Badge>REW-M03</Badge>
        </div>
        <p className="text-slate-500 mt-1">
          Mobile view: Redemption successful
        </p>
      </div>

      {/* Mobile Preview Container */}
      <div className="flex justify-center">
        <div className="w-full max-w-md border-4 border-slate-900 rounded-[3rem] overflow-hidden shadow-2xl bg-white">
          {/* Mobile Screen */}
          <div className="bg-white h-[700px] overflow-y-auto">
            {/* Success Header */}
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-4">
              <div className="flex items-center gap-3">
                <Link to="/rewards/mobile/list">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <h2 className="font-semibold">Redemption Successful</h2>
              </div>
            </div>

            {/* Success Animation Area */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-8 text-center">
              <div className="inline-flex p-6 bg-white rounded-full shadow-lg mb-4">
                <CheckCircle className="h-16 w-16 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                Reward Redeemed!
              </h2>
              <p className="text-slate-600">
                Your reward is ready to use
              </p>
            </div>

            {/* PIN Code Display */}
            <div className="p-6 space-y-6">
              <Card className="border-2 border-violet-200 bg-gradient-to-br from-violet-50 to-purple-50">
                <CardContent className="p-6 text-center">
                  <p className="text-sm text-slate-600 mb-2">Your Redemption PIN</p>
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <span className="text-4xl font-bold text-violet-600 tracking-wider font-mono">
                      {pinCode}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyPin}
                    className="gap-2"
                  >
                    <Copy className="h-4 w-4" />
                    Copy PIN Code
                  </Button>
                </CardContent>
              </Card>

              {/* Reward Details */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="p-3 bg-violet-100 rounded-xl">
                      <Gift className="h-8 w-8 text-violet-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg text-slate-900 mb-1">
                        Free Coffee Voucher
                      </h3>
                      <p className="text-sm text-slate-600">
                        Show this PIN at any participating café
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3 pt-3 border-t">
                    <div className="flex items-center gap-3 text-sm">
                      <Clock className="h-4 w-4 text-slate-400" />
                      <div>
                        <p className="text-slate-600">Expires in</p>
                        <p className="font-medium text-slate-900">{expiresIn}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <MapPin className="h-4 w-4 text-slate-400" />
                      <div>
                        <p className="text-slate-600">Valid at</p>
                        <p className="font-medium text-slate-900">150+ partner locations</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* How to Use */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-blue-600" />
                  How to Use
                </h4>
                <ol className="text-sm text-slate-600 space-y-2">
                  <li>1. Visit any participating café location</li>
                  <li>2. Show this PIN code to the staff</li>
                  <li>3. Staff will verify and apply your reward</li>
                  <li>4. Enjoy your free coffee!</li>
                </ol>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 sticky bottom-0 -mx-6 -mb-6 p-6 bg-white border-t">
                <Link to="/rewards/mobile/history" className="block">
                  <Button variant="outline" className="w-full">
                    View History
                  </Button>
                </Link>
                <Link to="/rewards/mobile/list" className="block">
                  <Button className="w-full">
                    Browse More Rewards
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
