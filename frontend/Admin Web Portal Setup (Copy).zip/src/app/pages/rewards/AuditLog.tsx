import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Search, Download, Filter, FileText } from 'lucide-react';

interface AuditEntry {
  id: string;
  timestamp: string;
  action: string;
  category: 'coupon' | 'pin' | 'reward' | 'user' | 'system';
  user: string;
  details: string;
  ipAddress: string;
  status: 'success' | 'failed' | 'warning';
}

const mockAuditLogs: AuditEntry[] = [
  {
    id: '1',
    timestamp: '2024-05-16 10:45:23',
    action: 'Coupon Created',
    category: 'coupon',
    user: 'Grace Admin',
    details: 'Created coupon SUMMER2024 with 20% discount',
    ipAddress: '192.168.1.100',
    status: 'success',
  },
  {
    id: '2',
    timestamp: '2024-05-16 10:42:15',
    action: 'PIN Verified',
    category: 'pin',
    user: 'Grace Staff',
    details: 'Verified PIN 123456 for user John Doe',
    ipAddress: '192.168.1.101',
    status: 'success',
  },
  {
    id: '3',
    timestamp: '2024-05-16 10:38:47',
    action: 'Reward Redeemed',
    category: 'reward',
    user: 'System',
    details: 'User Jane Smith redeemed Free Coffee Voucher',
    ipAddress: '10.0.0.45',
    status: 'success',
  },
  {
    id: '4',
    timestamp: '2024-05-16 10:35:12',
    action: 'Failed Login Attempt',
    category: 'system',
    user: 'Unknown',
    details: 'Failed login attempt for admin@example.com',
    ipAddress: '203.0.113.45',
    status: 'failed',
  },
  {
    id: '5',
    timestamp: '2024-05-16 10:30:56',
    action: 'Coupon Updated',
    category: 'coupon',
    user: 'Grace Manager',
    details: 'Updated max usage for WELCOME10 from 1000 to 5000',
    ipAddress: '192.168.1.102',
    status: 'success',
  },
  {
    id: '6',
    timestamp: '2024-05-16 10:25:33',
    action: 'User Role Changed',
    category: 'user',
    user: 'Grace Admin',
    details: 'Changed role for user@example.com from staff to manager',
    ipAddress: '192.168.1.100',
    status: 'success',
  },
  {
    id: '7',
    timestamp: '2024-05-16 10:20:18',
    action: 'Coupon Expired',
    category: 'coupon',
    user: 'System',
    details: 'Auto-expired coupon SPRING2024',
    ipAddress: 'System',
    status: 'warning',
  },
  {
    id: '8',
    timestamp: '2024-05-16 10:15:41',
    action: 'PIN Rejected',
    category: 'pin',
    user: 'Grace Staff',
    details: 'Rejected PIN 999999 - invalid code',
    ipAddress: '192.168.1.101',
    status: 'failed',
  },
  {
    id: '9',
    timestamp: '2024-05-16 10:10:22',
    action: 'Database Backup',
    category: 'system',
    user: 'System',
    details: 'Scheduled database backup completed',
    ipAddress: 'System',
    status: 'success',
  },
  {
    id: '10',
    timestamp: '2024-05-16 10:05:07',
    action: 'Reward Created',
    category: 'reward',
    user: 'Grace Admin',
    details: 'Created new reward: Premium Membership Trial',
    ipAddress: '192.168.1.100',
    status: 'success',
  },
];

export default function AuditLog() {
  const [logs, setLogs] = useState<AuditEntry[]>(mockAuditLogs);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || log.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || log.status === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-600';
      case 'failed':
        return 'bg-red-600';
      case 'warning':
        return 'bg-yellow-600';
      default:
        return 'bg-gray-600';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'coupon':
        return 'bg-blue-100 text-blue-700';
      case 'pin':
        return 'bg-purple-100 text-purple-700';
      case 'reward':
        return 'bg-green-100 text-green-700';
      case 'user':
        return 'bg-orange-100 text-orange-700';
      case 'system':
        return 'bg-slate-100 text-slate-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const handleExport = () => {
    // Mock export functionality
    console.log('Exporting audit logs...', filteredLogs);
    alert('Audit logs exported successfully!');
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold text-slate-900">Audit Log</h1>
            <Badge>REW-W03</Badge>
          </div>
          <p className="text-slate-500 mt-1">
            View and track all system activities and changes
          </p>
        </div>
        <Button onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          Export Logs
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Entries</CardDescription>
            <CardTitle className="text-3xl">{logs.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Success</CardDescription>
            <CardTitle className="text-3xl text-green-600">
              {logs.filter(l => l.status === 'success').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Failed</CardDescription>
            <CardTitle className="text-3xl text-red-600">
              {logs.filter(l => l.status === 'failed').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Warnings</CardDescription>
            <CardTitle className="text-3xl text-yellow-600">
              {logs.filter(l => l.status === 'warning').length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-1">
              <CardTitle>Activity Log</CardTitle>
              <CardDescription>Complete history of system activities</CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-initial">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search logs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-full sm:w-64"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[140px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="coupon">Coupon</SelectItem>
                  <SelectItem value="pin">PIN</SelectItem>
                  <SelectItem value="reward">Reward</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="system">System</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Details</TableHead>
                <TableHead>IP Address</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-mono text-xs whitespace-nowrap">
                    {log.timestamp}
                  </TableCell>
                  <TableCell className="font-medium">{log.action}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={getCategoryColor(log.category)}>
                      {log.category}
                    </Badge>
                  </TableCell>
                  <TableCell>{log.user}</TableCell>
                  <TableCell className="max-w-xs truncate">{log.details}</TableCell>
                  <TableCell className="font-mono text-xs">{log.ipAddress}</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(log.status)}>
                      {log.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredLogs.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">No audit logs found matching your filters</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
