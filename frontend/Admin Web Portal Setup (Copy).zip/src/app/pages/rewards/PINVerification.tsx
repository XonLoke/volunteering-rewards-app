import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Badge } from '../../components/ui/badge';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '../../components/ui/input-otp';
import { Alert, AlertDescription } from '../../components/ui/alert';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import { Hash, CheckCircle, XCircle, Clock, Search } from 'lucide-react';

// Aligned with user_coupons and redemption_logs schema from ERD
interface UserCoupon {
  id: string; // user_coupon_id
  user_id: string;
  user_name: string;
  coupon_id: string;
  coupon_title: string;
  pin_display: string; // For display only (real system uses pin_hash)
  status: 'unused' | 'used' | 'expired';
  redeemed_at?: string; // When coupon was originally redeemed for points
  verified_by?: number; // Cashier/Admin who verified the PIN
  verified_by_name?: string;
  expiry_date: string;
  created_at: string; // When user redeemed coupon for points
}

const mockUserCoupons: UserCoupon[] = [
  {
    id: '1',
    user_id: '4',
    user_name: 'John Volunteer',
    coupon_id: '1',
    coupon_title: '$50 FairPrice Voucher',
    pin_display: '8FGH12',
    status: 'used',
    redeemed_at: '2024-05-10T14:30:00Z',
    verified_by: 3,
    verified_by_name: 'Grace Cashier',
    expiry_date: '2024-12-31T23:59:59Z',
    created_at: '2024-05-10T10:00:00Z',
  },
  {
    id: '2',
    user_id: '5',
    user_name: 'Jane Volunteer',
    coupon_id: '2',
    coupon_title: 'Free Movie Tickets (2x)',
    pin_display: 'MV92K4',
    status: 'unused',
    created_at: '2024-05-15T09:00:00Z',
    expiry_date: '2024-11-30T23:59:59Z',
  },
  {
    id: '3',
    user_id: '4',
    user_name: 'John Volunteer',
    coupon_id: '3',
    coupon_title: '$20 Grab Voucher',
    pin_display: 'GR4B77',
    status: 'used',
    redeemed_at: '2024-05-12T16:00:00Z',
    verified_by: 3,
    verified_by_name: 'Grace Cashier',
    expiry_date: '2024-08-31T23:59:59Z',
    created_at: '2024-05-12T11:00:00Z',
  },
  {
    id: '4',
    user_id: '6',
    user_name: 'Bob Volunteer',
    coupon_id: '5',
    coupon_title: 'Gym Membership (1 Month)',
    pin_display: 'GYM123',
    status: 'unused',
    created_at: '2024-05-14T13:00:00Z',
    expiry_date: '2024-12-31T23:59:59Z',
  },
  {
    id: '5',
    user_id: '5',
    user_name: 'Jane Volunteer',
    coupon_id: '4',
    coupon_title: 'Starbucks Coffee Voucher',
    pin_display: 'SB789X',
    status: 'expired',
    created_at: '2024-04-20T10:00:00Z',
    expiry_date: '2024-06-30T23:59:59Z',
  },
];

export default function PINVerification() {
  const [pin, setPin] = useState('');
  const [verificationResult, setVerificationResult] = useState<{
    status: 'success' | 'error' | null;
    message: string;
    coupon?: UserCoupon;
  }>({ status: null, message: '' });
  const [userCoupons, setUserCoupons] = useState<UserCoupon[]>(mockUserCoupons);
  const [searchQuery, setSearchQuery] = useState('');

  const handleVerifyPIN = () => {
    if (pin.length !== 6) {
      setVerificationResult({
        status: 'error',
        message: 'Please enter a valid 6-character PIN',
      });
      return;
    }

    // Mock verification logic - in real system, would hash PIN and compare with pin_hash
    const found = userCoupons.find(uc =>
      uc.pin_display.toUpperCase() === pin.toUpperCase() && uc.status === 'unused'
    );

    if (found) {
      // Check if expired
      if (new Date(found.expiry_date) < new Date()) {
        setVerificationResult({
          status: 'error',
          message: `Coupon has expired on ${new Date(found.expiry_date).toLocaleDateString('en-SG')}`,
          coupon: found,
        });
        return;
      }

      setVerificationResult({
        status: 'success',
        message: `PIN verified successfully for ${found.user_name} - ${found.coupon_title}`,
        coupon: found,
      });

      // Update user_coupon status and create redemption_log entry
      setUserCoupons(prev =>
        prev.map(uc =>
          uc.id === found.id
            ? {
                ...uc,
                status: 'used' as const,
                redeemed_at: new Date().toISOString(),
                verified_by: 3, // Grace Cashier
                verified_by_name: 'Grace Cashier',
              }
            : uc
        )
      );
      setPin('');
    } else {
      setVerificationResult({
        status: 'error',
        message: 'Invalid PIN or coupon already used',
      });
    }
  };

  const filteredUserCoupons = userCoupons.filter(uc =>
    uc.pin_display.toLowerCase().includes(searchQuery.toLowerCase()) ||
    uc.user_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    uc.coupon_title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'used':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'expired':
        return <XCircle className="h-4 w-4 text-red-600" />;
      case 'unused':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'used':
        return 'bg-green-600';
      case 'expired':
        return 'bg-red-600';
      case 'unused':
        return 'bg-yellow-600';
      default:
        return 'bg-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-slate-900">PIN Verification</h1>
          <Badge>REW-W02</Badge>
        </div>
        <p className="text-slate-500 mt-1">
          Verify volunteer coupon PINs at participating stores
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Coupons</CardDescription>
            <CardTitle className="text-3xl">{userCoupons.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Unused</CardDescription>
            <CardTitle className="text-3xl text-yellow-600">
              {userCoupons.filter(uc => uc.status === 'unused').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Used Today</CardDescription>
            <CardTitle className="text-3xl text-green-600">
              {userCoupons.filter(uc => uc.status === 'used').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Expired</CardDescription>
            <CardTitle className="text-3xl text-red-600">
              {userCoupons.filter(uc => uc.status === 'expired').length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Verification Form */}
      <Card>
        <CardHeader>
          <CardTitle>Verify PIN Code</CardTitle>
          <CardDescription>
            Enter the volunteer's 6-character coupon PIN to verify usage
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col items-center gap-4 py-4">
            <div className="space-y-2 text-center">
              <Label htmlFor="pin-input" className="text-lg">Enter PIN Code</Label>
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={pin}
                  onChange={setPin}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>

            <Button 
              onClick={handleVerifyPIN} 
              size="lg"
              disabled={pin.length !== 6}
            >
              <Hash className="h-4 w-4 mr-2" />
              Verify PIN
            </Button>

            {verificationResult.status && (
              <Alert
                variant={verificationResult.status === 'success' ? 'default' : 'destructive'}
                className="max-w-md"
              >
                <AlertDescription className="flex items-center gap-2">
                  {verificationResult.status === 'success' ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    <XCircle className="h-4 w-4" />
                  )}
                  {verificationResult.message}
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Verification History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Coupon Usage History</CardTitle>
              <CardDescription>Track coupon redemptions and PIN verifications</CardDescription>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search verifications..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>PIN</TableHead>
                <TableHead>Volunteer</TableHead>
                <TableHead>Coupon</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Redeemed</TableHead>
                <TableHead>Expiry</TableHead>
                <TableHead>Verified By</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUserCoupons.map((userCoupon) => (
                <TableRow key={userCoupon.id}>
                  <TableCell className="font-mono font-medium">{userCoupon.pin_display}</TableCell>
                  <TableCell>{userCoupon.user_name}</TableCell>
                  <TableCell className="max-w-xs truncate">{userCoupon.coupon_title}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(userCoupon.status)}
                      <Badge className={getStatusColor(userCoupon.status)}>
                        {userCoupon.status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">
                    {userCoupon.redeemed_at
                      ? new Date(userCoupon.redeemed_at).toLocaleDateString('en-SG')
                      : '-'}
                  </TableCell>
                  <TableCell className="text-sm">
                    {new Date(userCoupon.expiry_date).toLocaleDateString('en-SG')}
                  </TableCell>
                  <TableCell>{userCoupon.verified_by_name || '-'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
