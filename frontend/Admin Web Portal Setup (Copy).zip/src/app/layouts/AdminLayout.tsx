import { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '../components/ui/sheet';
import { Badge } from '../components/ui/badge';
import {
  LayoutDashboard,
  Ticket,
  Hash,
  FileText,
  Users,
  Settings,
  ChevronDown,
  Menu,
  LogOut,
  Gift,
  Smartphone,
  BarChart3,
  Shield,
  Bell,
} from 'lucide-react';

interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  roles?: string[];
}

const navItems: NavItem[] = [
  { title: 'Dashboard', href: '/', icon: LayoutDashboard },
  { title: 'Coupon Management', href: '/rewards/coupons', icon: Ticket, badge: 'REW-W01' },
  { title: 'PIN Verification', href: '/rewards/pin-verify', icon: Hash, badge: 'REW-W02' },
  { title: 'Audit Log', href: '/rewards/audit', icon: FileText, badge: 'REW-W03' },
  { title: 'Mobile: Rewards List', href: '/rewards/mobile/list', icon: Smartphone, badge: 'REW-M01' },
  { title: 'Mobile: Details', href: '/rewards/mobile/details', icon: Gift, badge: 'REW-M02' },
  { title: 'Mobile: Redeem', href: '/rewards/mobile/redeem', icon: Hash, badge: 'REW-M03' },
  { title: 'Mobile: History', href: '/rewards/mobile/history', icon: BarChart3, badge: 'REW-M04' },
  { title: 'User Management', href: '/admin/users', icon: Users, badge: 'WEB-02', roles: ['Admin'] },
  { title: 'Analytics', href: '/admin/analytics', icon: BarChart3, badge: 'WEB-03' },
  { title: 'Notifications', href: '/admin/notifications', icon: Bell, badge: 'WEB-04' },
  { title: 'Roles & Permissions', href: '/admin/roles', icon: Shield, badge: 'WEB-05', roles: ['Admin'] },
  { title: 'Settings', href: '/admin/settings', icon: Settings, badge: 'WEB-06' },
];

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const location = useLocation();
  const { user } = useAuth();

  const filteredNavItems = navItems.filter(item => {
    if (!item.roles) return true;
    return user && item.roles.includes(user.role);
  });

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-violet-600 rounded-lg">
            <Gift className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="font-semibold">Rewards Admin</h1>
            <p className="text-xs text-slate-400">Grace's Portal</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-1">
          {filteredNavItems.map((item) => {
            const isActive = location.pathname === item.href;
            const Icon = item.icon;
            
            return (
              <Link
                key={item.href}
                to={item.href}
                onClick={onNavigate}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-violet-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="flex-1 text-sm">{item.title}</span>
                {item.badge && (
                  <Badge
                    variant="secondary"
                    className="text-xs px-1.5 py-0.5 bg-slate-700 text-slate-300"
                  >
                    {item.badge}
                  </Badge>
                )}
              </Link>
            );
          })}
        </div>
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="text-xs text-slate-500">
          <p>Logged in as</p>
          <p className="text-slate-300 mt-1">{user?.role || 'Guest'}</p>
        </div>
      </div>
    </div>
  );
}

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="h-screen flex overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 border-r">
        <Sidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="border-b bg-white px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Mobile Menu Toggle */}
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="lg:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <Sidebar onNavigate={() => setMobileMenuOpen(false)} />
                </SheetContent>
              </Sheet>

              <div>
                <h2 className="font-semibold text-slate-900">
                  Welcome back, {user?.name}!
                </h2>
                <p className="text-sm text-slate-500">
                  Manage your rewards and admin portal
                </p>
              </div>
            </div>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-violet-600 text-white">
                      {user?.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left hidden sm:block">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-slate-500">{user?.role}</p>
                  </div>
                  <ChevronDown className="h-4 w-4 text-slate-500" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-slate-50 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
